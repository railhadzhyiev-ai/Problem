# DE100 word-pipeline: описание проблемы и результаты тестов

Отчёт по сохранённому состоянию на 7 октября 2026 года.
Актуальный код: bc4a3da6045daa3314f6c02fb0b955dfd41b570c.
Последний завершённый field-repair run: 37550962140, COMPLETE_100_DE, 2026-10-07 00:50 UTC.

## Основная цель на выходе

Получать из DE word-pipeline не только AI-generated candidates, а воспроизводимые, проверенные карточки слов, пригодные к admission по действующим правилам.

Ожидаемый результат для каждой допущенной карточки:
- соответствие реальному wire-contract v2;
- явно подтверждённые critical fields: язык, lemma, POS и согласованные word/sense/localization identities;
- заполненные и проверенные применимые обязательные morphology, смыслы/glosses и RU/UK/AZ translations;
- корректные примеры, explanations и переводы, согласованные со смыслом и исходными предложениями;
- source и AI provenance сохраняются раздельно, допустимые источники и подтверждения привязаны к конкретным полям;
- QA receipt соответствует точному hash окончательной карточки; изменение карточки требует нового соответствующего подтверждения;
- выполнены существующие evidence/admission gates без ослабления policy или подмены source verification AI QA;
- canonical identifiers и admission выдаются только установленной canonical процедурой, не присваиваются staging-кандидатам автоматически.

Отсутствующие OPTIONAL IPA/CEFR/relations не должны сами по себе блокировать shadow gate. Применимые обязательные поля и unsupported N/A не могут быть пропущены или выдуманы.

Главный диагностический результат: объяснить для frozen 100 DE, какие конкретные проверки блокируют переход GENERATED_CANDIDATE -> verified/admission-ready, и какие подтверждения/исправления реально нужны. Нужна проверяемая связь final card -> field evidence -> exact-card QA -> gate verdict, а не только улучшение общей статистики.

Критерий успеха: реальные карточки достигают verified/admission-ready с полным проверяемым evidence trail; остальные получают точные per-card/per-field причины отказа. SHADOW_PASS, AI_VERIFIED и canonical admission остаются разными состояниями. Автоматическое ACCEPT всех 100 карточек не является критерием успеха.

## Основная проблема

После AI-generation, deterministic repair и отдельного AI QA ни одна из 100 DE-карточек не достигла SHADOW_PASS или canonical admission.

Проверки обнаруживают несколько независимых препятствий:

1. Структура wire-contract v2: после последнего field repair только 47/100 карточек проходят structural validation.
2. Языковая и смысловая QA: только 22/100 имеют language QA PASS. Этот показатель сам по себе не подтверждает admission.
3. Положительное подтверждение critical fields: frozen lemma/POS получены из corpus/NLP selection. REPAIR_PLAN report фиксирует 0/100 независимо проверенных lemma/POS. Shadow-политика требует явного подтверждения; отсутствие QA-жалобы подтверждением не считается.
4. Источники и provenance: corpus selection и AI QA не заменяют независимые допустимые lexical evidence. В исходном offline replay EVIDENCE_GATE PASS = 0/100.
5. Canonical boundary: staging IDs не являются canonical identities. SHADOW_PASS не равен CANONICAL_ADMITTED; shadow-эксперимент не меняет admission policy.

Детерминированный repair исправляет техническую сериализацию и механические ссылки. Он не может создать отсутствующие лингвистические доказательства или автоматически подтвердить lemma/POS и sense correctness.

Исследовательский вопрос:
Почему AI-generated candidates остаются unverified/admission-blocked после структурного repair и отдельного AI QA, и какие конкретные per-card/per-field blockers сохраняются при exact-card QA binding?

## Последние результаты DE100

Источник: точный JSON stdout report завершённого run 37550962140; original artifact ещё не распакован в diagnostic snapshot.

| Показатель | Значение |
| --- | ---: |
| Обработано | 100 |
| Structural PASS | 47 |
| Language QA PASS | 22 |
| SHADOW_PASS | 0 |
| CONFLICT | 45 |
| INCOMPLETE | 12 |
| QUARANTINE_CANDIDATE | 43 |
| Applied field repairs | 613 |
| QA-confirmed false alarms | 268 |
| Failed cards | 4 |
| Historical repair + QA requests | 156 |
| Retries | 0 |
| Изменённые identity targets | 0 |
| Canonical admitted | 0 |
| Production writes | 0 |
| Repair + QA cost, USD | 3.50527865 |
| Total original pilot + repair cost, USD | 4.570035 |

CONFLICT/INCOMPLETE/QUARANTINE_CANDIDATE — итоговые shadow verdicts и суммируются в 100.
Structural PASS, language QA PASS и failedCards — другие характеристики; их нельзя складывать с verdict distribution.
Стоимость на SHADOW_PASS не определена, поскольку SHADOW_PASS = 0.

## До последнего field repair

Это две разные технические проекции; показатели не следует смешивать.

| Показатель | Более ранний offline replay | Строгий deterministic REPAIR_PLAN |
| --- | ---: | ---: |
| Обработано | 100 | 100 |
| Structural/technical PASS | 22 | 40 |
| Structural/technical FAIL | 78 | 60 |
| Repair operations | 714 | 848 |
| Language QA PASS по сохранённым findings | 10 | Не измерялось этой сводкой |
| EVIDENCE_GATE PASS | 0 | Не измерялось этой сводкой |
| Admission-ready | 0 | Не измерялось этой сводкой |
| Repair-plan field targets | — | 1473 |
| Confirmed missing fields | — | 955 |
| QA review targets | — | 506 |
| Identity review targets | — | 12 |
| Независимо проверенные lemma/POS | — | 0 |

Строгий REPAIR_PLAN forecast охватывал 81 semantic repair candidate card.
Фактический field-repair preflight выбрал 80 repair cards и верхнюю границу 160 запросов; фактически сохранено 156. Это разные стадии отбора, а не одна метрика.

## Результаты offline control tests

В diagnostic snapshot реально выполнены четыре существующих test-файла:
28 PASS / 0 FAIL / 0 SKIP.

| Test file | Tests | Что проверяет |
| --- | ---: | --- |
| canonicalword-replay-v2.test.mjs | 6 | Mechanical identity restoration, сохранность raw, запрет invented localization, сохранение mixed semantic findings, ограничение senses |
| deterministic-repair-v2.test.mjs | 5 | Disjoint serialization repair, refusal при конфликтах, ordered staging IDs, exact-sentence translation reuse без выдумывания |
| ai-admission-shadow-v1.test.mjs | 12 | Positive synthetic control; 8 mutations invalidating exact-card QA; отказ без QA/critical confirmation; semantic conflict |
| field-repair-v1.test.mjs | 5 | Allowed field scope, hashes/preconditions, запрет identity/full-card changes, отказ от duplicate/invented sense patches, dependencies между patches |

Исходный test output включён в TEST_RESULTS.txt.
Эти controls проверяют реализацию ограничений, binding и отказов. 28 PASS не означает, что 100 реальных карточек лингвистически правильны.
Flutter/Dart runtime, production database и полный app test suite этим отчётом не заявляются.

## Проверяемость и пределы вывода

В diagnostic repository подтверждены source Git blob hashes, frozen checksums и ровно 100 DE input rows.
Сводки в этом ZIP взяты из сохранённого stdout; raw job logs не включены.
Полные generation ledger, latest repair ledger, standalone repaired projection и REPAIR_PLAN ещё не импортированы и не исследованы побайтово в diagnostic snapshot.
Поэтому детальный root-cause breakdown для каждой из 100 карточек требует оригинальных per-card/per-field receipts. Недостающие свидетельства в этом отчёте не восстановлены и не выдуманы.

## Где сохранены оригиналы

Generation ZIP:
Actions run 37546161114 / artifact 11451059770
Размер: 161522 bytes
SHA-256: ce732dacfac378620dad28a25f1c86e1d90ec8e83d41d94089dacbda76e48e99

Latest field-repair ZIP:
Actions run 37550962140 / artifact 11453987714
Размер: 547689 bytes
SHA-256: e1d9821ab1ebf4b461f25b4865080d607f3ec042dbe74b13674d77944759853c

Generation ledger SHA-256 из сохранённого preflight:
4fdfea937b9aeac0b8c6effbe3f7660577cbe33c459944f509060aa6ee7ae8f4

Полный REPAIR_PLAN SHA-256 из сохранённого preflight:
6093ec70376a6841f5ccf9e1bacd55013ad53ea7ebb51e8383915948694609e6

Состав обоих оригинальных bundles по writer/upload logs: ledger.json, report.json, checksums.sha256.
Центральный каталог этих оригинальных ZIP не прочитан. Member sizes/hashes, кроме указанного generation ledger, не подтверждены.
Отдельные outputs projection/REPAIR_PLAN не входили в upload paths. Их существование на runner подтверждено логами; сохранённые локальные копии ещё не найдены.
58 текущих source branches и история известных output/build paths в pipeline-ветке проверены: Git-копий этих originals не найдено.
Локальные workspace/temp/download каталоги не проверены из-за отсутствия filesystem tools.

## Содержимое этого отчётного ZIP

REPORT_RU.md — описание проблемы, метрики, tests и ограничения.
TEST_RESULTS.txt — сохранённый результат 28 controls.
offline-replay.stdout-report.json — исходная replay-сводка из stdout.
repair-plan.stdout-report.json — deterministic REPAIR_PLAN сводка из stdout.
latest-field-repair.stdout-report.json — последняя QA/shadow сводка из stdout.
PROVENANCE.json — источники и хеши отчётных файлов.
CHECKSUMS.sha256 — проверка содержимого этого отчётного ZIP.

Это новый архив отчёта, не regeneration/rebuild оригинального pipeline.
Новые модельные API-вызовы, изменения исходного pipeline или копирование original bundles для подготовки отчёта не выполнялись.
